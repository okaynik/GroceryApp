//
//  Item.swift
//  Grocery
//
//  Created by nikita on 5/2/20.
//  Copyright © 2020 nikita. All rights reserved.
//

import Foundation

public class Item {
    
    private var name = ""
    private var id = 0
    
    init(_ name:String, _ id:Int) {
        self.name = name
        self.id = id
    }
    
    
}
