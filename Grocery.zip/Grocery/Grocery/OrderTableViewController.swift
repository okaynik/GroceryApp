import UIKit

class Item : Comparable {
    var name: String
    var amount: String
    
    init(name:String, amount:String){
        self.name = name
        self.amount = amount
    }
    static func < (lhs: Item, rhs: Item) -> Bool {
        return lhs.name < rhs.name
    }
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        return lhs.name == rhs.name
    }
}
class Order {
    let name = "Order"
    var id: String
    var list: [Item]
    
    init(list:[Item], id:String){
        self.id = id
        self.list = list
    }
}

class OrderTableViewController: UITableViewController{

    @IBOutlet weak var orderTable:
    UITableView!
    
    var data = [Order]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Delau test materiali
        let cola = Item(name: "Coca-Cola", amount:  "45")
        let bread = Item(name: "Bread", amount: "20")
        let soap = Item(name: "Soap", amount: "3")
        data = [Order(list: [cola, bread, soap], id: "1"), Order(list: [bread, cola], id: "2"), Order(list: [soap], id: "3")]
        
        orderTable.dataSource = self
        orderTable.delegate = self
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "order")
        if cell == nil{
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "order")
        }
        
        cell?.textLabel?.text = "\(data[indexPath.row].name) \(String(describing: data[indexPath.row].id))"
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return data.count
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //tableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "showdetail", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? TableViewController{
            destination.data = data[(orderTable.indexPathForSelectedRow?.row)!].list
        }
    }

}
